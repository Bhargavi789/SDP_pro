from django.contrib import admin

from .models import Suppliers, Items

admin.site.register(Suppliers)
admin.site.register(Items)
